# 🌾 AgriSage AI Project

The complete code for **AgriSage AI** is located in the **[`agrisage/`](./agrisage/)** folder.

### Quick Start:
```bash
cd agrisage
pip install -r requirements.txt
python test_agents.py
streamlit run app.py
```
Or simply double-click **`agrisage/run.bat`** on Windows!

See full documentation, viva answers, and architecture in [agrisage/README.md](./agrisage/README.md).

